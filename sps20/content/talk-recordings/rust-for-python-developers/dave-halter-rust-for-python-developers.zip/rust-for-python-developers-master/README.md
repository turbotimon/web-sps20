# Rust for Python Developers

Please open the slides at reveal.js-master/index.html in your browser.
